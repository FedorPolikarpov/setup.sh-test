#!/usr/bin/env bash

set -x
set -e

. env.sh

if [ -f /opt/openiam/webapps/env.sh ]
then
  . /opt/openiam/webapps/env.sh
fi

if [ -z "${OPENIAM_RPROXY_HTTP}" ]; then
    echo "set OPENIAM_RPROXY_HTTP to 1 (recommended) or 0 (not recommended, unless you have load balancer with https in front of rproxy)"
    exit 1
fi


if [ "${OPENIAM_RPROXY_HTTP}" -eq 0 ]; then
if [ -z "${OPENIAM_SSL_CERT}" ]; then
    if [ -z "${OPENIAM_SSL_CHAIN}" ]; then
        echo "set OPENIAM_SSL_CERT or OPENIAM_SSL_CHAIN to correct path to ssl certificate or ssl certificates chain"
        exit 1
    fi
fi

if [ -z "${OPENIAM_SSL_CERT_KEY}" ]; then
    echo "set OPENIAM_SSL_CERT_KEY_PATH to correct path to ssl certificate private key"
    exit 1
fi
fi

# configure docker networks
 if [[ ! "$(docker network ls | grep openiam_private)" ]]; then
    docker network create --attachable  --driver=overlay openiam_private
    sleep 5
fi

docker pull "openiamdocker/flyway${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/esb${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/workflow${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/idm${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/groovy-manager${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/business-rule-manager${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/synchronization${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/email-manager${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/device-manager${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/auth-manager${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
# deploy sas-manager module
#docker pull "openiamdocker/sas-manager${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"


if [[ "$DB_TYPE" == 'MariaDB' ]]; then
    docker pull "openiamdocker/mariadb${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
fi

if [[ "$DB_TYPE" == 'Postgres' ]]; then
    docker pull "openiamdocker/postgres${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
fi


docker pull "openiamdocker/reconciliation${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/redis${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/janusgraph${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/elasticsearch${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/rabbitmq${IMAGE_SUFFIX}:alpine-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/openiam-metadata${IMAGE_SUFFIX}:alpine-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#connectors
docker pull "openiamdocker/ldap-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/google-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/linux-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/oracle-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/scim-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/aws-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/script-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/oracle-ebs-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/freshdesk-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/oracle-idcs-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/tableau-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/adp-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/ipa-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/salesforce-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/jdbc-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/box-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/kronos-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/workday-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/workday-rest-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/boomi-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/lastpass-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/thales-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/thales-wsdl-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/postgresql-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#docker pull "openiamdocker/rexx-connector-rabbitmq${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#rproxy
docker pull "openiamdocker/rproxy${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
#source adapter. commented due to this is optional
#docker pull "openiamdocker/http-source-adapter${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"

#data analyzing tool
 if [[ "OPENIAM_MONITORING_TOOLS_ENABLED" -eq 1 ]]; then
    docker pull "docker.elastic.co/beats/metricbeat:${OPENIAM_MONITORING_TOOLS_VERSION}"
    docker pull "docker.elastic.co/beats/filebeat:${OPENIAM_MONITORING_TOOLS_VERSION}"
    docker pull "docker.elastic.co/kibana/kibana:${OPENIAM_MONITORING_TOOLS_VERSION}"
fi
docker pull bitnami/etcd:3.3.13
docker pull bitnami/cassandra:3.11.10
docker pull "openiamdocker/vault${IMAGE_SUFFIX}:alpine-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
docker pull "openiamdocker/vault-bootstrap${IMAGE_SUFFIX}:alpine-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"

docker pull "openiamdocker/ui${IMAGE_SUFFIX}:debian-${OPENIAM_VERSION_NUMBER}-${BUILD_ENVIRONMENT}"
