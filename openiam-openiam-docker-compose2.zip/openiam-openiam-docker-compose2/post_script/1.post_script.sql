use openiam;
/* dummy post script SQL file */